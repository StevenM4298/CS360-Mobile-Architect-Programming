package com.example.burnerweightloss;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.util.Log;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.text.TextWatcher;
import android.content.Intent;

public class Login extends AppCompatActivity {

    //Login screen variables
    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonSubmitCredentials;
    private Button buttonNewUser;


    //First screen to run is login
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonSubmitCredentials = findViewById(R.id.buttonSubmitCredentials);
        buttonNewUser = findViewById(R.id.buttonNewUser);

        buttonSubmitCredentials.setOnClickListener(this::LoginCredentials);

        buttonNewUser.setOnClickListener(this::Register);
    }

    //Method to login
    public void LoginCredentials(View view) {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        //Store credentials under "User Accounts"
        SharedPreferences prefs = getSharedPreferences("UserAccounts", MODE_PRIVATE);
        //Checks if the username exists and responds if it doesn't
        if (!prefs.contains(username)) {
            Toast.makeText(this, "Account not found", Toast.LENGTH_SHORT).show();
            return;
        }
        //Gets the password associated with the username
        String storedPassword = prefs.getString(username,"");

        //If the stored password matches with username successfully
        if (storedPassword.equals(password)) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, Homepage.class));
            finish();

        //If password doesn't match correctly for username, state incorrect PW
        } else {
            Toast.makeText(this, "Incorrect password", Toast.LENGTH_SHORT).show();
        }
    }

    //Set a new user when the register button is clicked on
    public void Register(View view) {
        //Get the username and password input
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        //Adds the new user credentials to the "User Accounts" storage
        SharedPreferences prefs = getSharedPreferences("UserAccounts", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        //Store
        editor.putString(username, password);
        editor.apply();
        //Give notification of successful user creation
        Toast.makeText(this, "New user created", Toast.LENGTH_SHORT).show();
    }
}