package com.example.burnerweightloss;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.widget.ProgressBar;
public class Grid {
    private String date;
    private String weekday;
    private float weight;

    public Grid(String date, String weekday, float weight) {
        this.date = date;
        this.weekday = weekday;
        this.weight = weight;
    }

    public String getDate() { return date; }
    public String getWeekday() { return weekday; }
    public float getWeight() { return weight; }
}

