package com.example.burnerweightloss;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.widget.ProgressBar;
import java.util.ArrayList;
import java.util.List;

public class Calendar extends AppCompatActivity {

    private RecyclerView weightRecyclerView;
    private WeightAdapter adapter;
    private List<Grid> weightList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        weightRecyclerView = findViewById(R.id.weightRecyclerView);
        weightRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        weightList = new ArrayList<>();

        adapter = new WeightAdapter(weightList);
        weightRecyclerView.setAdapter(adapter);
    }

    public void homeButton(View view) {
        Intent intent = new Intent(this, Homepage.class);
        startActivity(intent);
        finish();
    }
}
