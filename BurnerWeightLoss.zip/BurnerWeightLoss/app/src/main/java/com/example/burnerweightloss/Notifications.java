package com.example.burnerweightloss;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.widget.ProgressBar;

public class Notifications extends AppCompatActivity {

    private Switch smsSwitch;

    //run the notifications screen
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_notifications);

        smsSwitch = findViewById(R.id.smsSwitch);

    }

    public void homeButton(View view) {
        Intent intent = new Intent(this, Homepage.class);
        startActivity(intent);
        finish();
    }
}
