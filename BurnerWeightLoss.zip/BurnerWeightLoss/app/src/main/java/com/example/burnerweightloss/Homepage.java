package com.example.burnerweightloss;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.widget.ProgressBar;


public class Homepage extends AppCompatActivity {
    //Homepage variables
    private EditText addNewWeight;
    private EditText editGoal;
    private Button buttonAddWeightData;
    private Button buttonCalendarGrid;
    private Button buttonNewGoal;
    private TextView currentWeight;
    private TextView currentDate;
    private TextView displayCurrentWeight;
    private ProgressBar progressBar;
    private TextView remainingLBS;

    //run the homepage screen
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_homepage);

        addNewWeight = findViewById(R.id.addNewWeight);
        editGoal = findViewById(R.id.editGoal);
        buttonAddWeightData = findViewById(R.id.buttonAddWeightData);
        buttonCalendarGrid = findViewById(R.id.buttonCalendarGrid);
        buttonNewGoal = findViewById(R.id.buttonNewGoal);
        displayCurrentWeight = findViewById(R.id.displayCurrentWeight);
        progressBar = findViewById(R.id.progressBar);
        remainingLBS = findViewById(R.id.remainingLBS);

        buttonAddWeightData.setOnClickListener(this::AddWeight);
        buttonCalendarGrid.setOnClickListener(this::CalendarGrid);
        buttonNewGoal.setOnClickListener(this::NewGoal);

        currentWeight = findViewById(R.id.CurrentWeight);
        currentDate = findViewById(R.id.CurrentDate);

        CurrentWeight();
        CurrentDate();
        ProgressBar();
    }

    //Display today's date
    public void CurrentDate() {
        String today = new SimpleDateFormat("MMMM d", Locale.getDefault())
                .format(new Date());
        currentDate.setText("Today, " + today);
    }

    //Add a new weight
    public void AddWeight(View view) {
        String input = addNewWeight.getText().toString().trim();
        float newWeight;

        try {
            newWeight = Float.parseFloat(input);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid weight format", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences prefs = getSharedPreferences("StoredWeight", MODE_PRIVATE);
        prefs.edit().putFloat("currentWeight", newWeight).apply();

        displayCurrentWeight.setText(newWeight + " lbs");
        addNewWeight.setText("");

        Toast.makeText(this, "New weight added", Toast.LENGTH_SHORT).show();

        ProgressBar();

    }

    //Display the updated saved weight on the homepage
    public void CurrentWeight() {
        SharedPreferences prefs = getSharedPreferences("StoredWeight", MODE_PRIVATE);
        float savedWeight = prefs.getFloat("currentWeight", 0);

        if (savedWeight != 0) {
            displayCurrentWeight.setText(savedWeight + " lbs");
        } else {
            displayCurrentWeight.setText("0.0 lbs");
        }
    }

    public void CalendarGrid(View view) {
        Intent intent = new Intent(this, Calendar.class);
        startActivity(intent);

    }

    //Progress Bar
    public void ProgressBar() {
        SharedPreferences prefs = getSharedPreferences("StoredWeight", MODE_PRIVATE);
        float current = prefs.getFloat("currentWeight", 0);
        float goal = prefs.getFloat("goalWeight", 0);
        float saved = prefs.getFloat("savedWeight", current);
        //Start with displaying current weight
        displayCurrentWeight.setText(String.format(Locale.getDefault(), "%.1f", current));

        //Calculate the number of lbs left until goal
        if (current > 0 && goal > 0) {
            float remaining = Math.max(current - goal, 0);
            remainingLBS.setText(String.format(Locale.getDefault(), "%.1f", remaining));

            float numberLeft = saved - goal;
            float amountLost = saved - current;

            if (numberLeft > 0) {
                int progressPercent = (int) ((amountLost / numberLeft) * 100);
                progressBar.setProgress(Math.min(Math.max(progressPercent, 0), 100));
            } else {
                progressBar.setProgress(0);
            }
        }

        if (current <= goal) {
            Toast.makeText(this, "Congratulations! Your goal has been reached. To continue, enter a new goal.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    public void NewGoal(View view) {
        String newGoalInput = editGoal.getText().toString().trim();

        try {
            float goalWeight = Float.parseFloat(newGoalInput);

            SharedPreferences prefs = getSharedPreferences("StoredWeight", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            // Save the goal
            editor.putFloat("goalWeight", goalWeight);

            //Starting the progress with the current weight
            if (prefs.getFloat("savedWeight", 0) == 0) {
                float current = prefs.getFloat("currentWeight", 0);
                editor.putFloat("savedWeight", current);
            }

            editor.apply();
            editGoal.setText("");

            Intent intent = new Intent(this, Notifications.class);
            startActivity(intent);

            //Update progress
            ProgressBar();
            Toast.makeText(this, "New goal added!", Toast.LENGTH_SHORT).show();

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Error. Invalid format.", Toast.LENGTH_SHORT).show();
        }
    }
}