package com.example.burnerweightloss;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.widget.ProgressBar;
import java.util.ArrayList;
import java.util.List;
import androidx.recyclerview.widget.RecyclerView;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder>{
    private List<Grid> weightList;

    public WeightAdapter(List<Grid> weightList) {
        this.weightList = weightList;
    }

    @NonNull
    @Override
    public WeightAdapter.WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_weight_grid, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightAdapter.WeightViewHolder holder, int position) {
        Grid entry = weightList.get(position);

        holder.textDate.setText(entry.getDate());
        holder.textWeekday.setText(entry.getWeekday());
        holder.textWeight.setText(String.format(Locale.getDefault(), "%.1f", entry.getWeight()));

    }

    public int getItemCount() {
        return weightList.size();
    }

    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView textDate, textWeekday, textWeight;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            // Link Java variables to the XML IDs
            textDate = itemView.findViewById(R.id.textDate);
            textWeekday = itemView.findViewById(R.id.textWeekday);
            textWeight = itemView.findViewById(R.id.textWeight);
        }
    }
}
